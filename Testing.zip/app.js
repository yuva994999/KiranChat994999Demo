var bodyparser = require('body-parser');
var natural = require('natural');
var express = require('express');
var app= express();
var https = require("https");
const path = require('path');
var soundex = require('soundex-code')


const XLSX=require('xlsx');
const workbook = XLSX.readFile('KnowlegeRepository.xlsx');
const sheet_data = workbook.SheetNames;
var a=XLSX.utils.sheet_to_json(workbook.Sheets[sheet_data[0]]);
app.set('view engine','ejs');
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());
//app.use(function(req,res,next){
// res.locals.user = 'first';
// next();
//})
/* app.get('/',function(req,res){
res.sendFile(path.join(__dirname+'/logintry.html'));
})

app.get('/home',function(req,res){
res.sendFile(path.join(__dirname+'/home.html'));
})

app.get('/logintry',function(req,res){
res.sendFile(path.join(__dirname+'/logintry.html'));
}) */

app.use(express.static(path.join(__dirname,
'public')));

app.get('/',function(req,res){

res.sendFile(path.join(__dirname+'/help.html'));

})

/* app.get('/customer',function(req,res){
res.sendFile(path.join(__dirname+'/customer.html'));

})
app.get('/policy',function(req,res){
res.sendFile(path.join(__dirname+'/policy.html'));

})
app.get('/schemeloader',function(req,res){
res.sendFile(path.join(__dirname+'/schemeloader.html'));

})
app.get('/claim',function(req,res){
res.sendFile(path.join(__dirname+'/claim.html'));

})
app.get('/tiaflex',function(req,res){
res.sendFile(path.join(__dirname+'/tiaflex.html'));

})
app.get('/account',function(req,res){
res.sendFile(path.join(__dirname+'/account.html'));

})
app.get('/letters',function(req,res){
res.sendFile(path.join(__dirname+'/letters.html'));

}) */

app.get('/search',function(req,res){
res.render('home',{Ans:'',title:'',Suggestions:''});


})
app.post('/search',function(req,res){
var Question = req.body.Question;
var data='',data2='';
var data1='';

/* var soundex = function (s) {
     var a = s.toLowerCase().split(''),
         f = a.shift(),
         r = '',
         codes = {
             a: '', e: '', i: '', o: '', u: '',
             b: 1, f: 1, p: 1, v: 1,
             c: 2, g: 2, j: 2, k: 2, q: 2, s: 2, x: 2, z: 2,
             d: 3, t: 3,
             l: 4,
             m: 5, n: 5,
             r: 6
         };
 
     r = f +
         a
         .map(function (v, i, a) { return codes[v] })
         .filter(function (v, i, a) {
             return ((i === 0) ? v !== codes[f] : v !== a[i - 1]);
         })
         .join('');
 
     return (r + '000').slice(0, 4).toUpperCase();
};
 */

/* console.log(Link); */
/* global.globalString =Question;
 */
 for(var element of a)
{
    if((element['Question'].toLowerCase().match(Question.toLowerCase())) ||(soundex(Question)===soundex(element['Question'])))  {
		data=element['Answer'];
		data1=element['Question'];
		data2=element['Link'];
       break;
    }
    else{
        data='No answer found in repository';
    }
}
 
/* app.get('/users', function(req, res) {
  res.send(Question);
}); */
res.render('home',{Ans:[data],title:[data1],Suggestions:[data2]});
/* module.exports.variableName =Question;.
 */
})


app.listen(3000,"10.252.204.51",function(){
console.log('listening to server at port 3000');
})